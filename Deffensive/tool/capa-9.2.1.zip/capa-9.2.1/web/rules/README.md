# capa rules documentation website

## requirements

  - [just](https://github.com/casey/just)
  - [pagefind](https://pagefind.app/)
  - `pip install -r requirements`

## building

```
just clean
just build
````

then `just serve` and visit http://127.0.0.1:8000/ or (upload `./public` somewhere).
